//
//  version.h
//  ASTFrameworkAPI
//
//  Created by Jorge Ferrando on 12/04/13.
//  Copyright (c) 2013 Jorge Ferrando. All rights reserved.
//

#pragma once

#define AST_VERSION_MAJOR  1
#define AST_VERSION_MINOR  2
#define AST_VERSION_BUGFIX 1
#define AST_VERSION_STRING "1.2.1"